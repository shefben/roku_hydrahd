' HomeView.brs - RowList of categories from the hydrahd index page.

sub init()
    m.rows = m.top.findNode("rows")
    m.empty = m.top.findNode("empty")
    m.hero = m.top.findNode("hero")
    m.heroBackdrop = m.top.findNode("heroBackdrop")
    m.heroTitle = m.top.findNode("heroTitle")
    m.heroMeta = m.top.findNode("heroMeta")
    m.heroDesc = m.top.findNode("heroDesc")
    m.descTimer = m.top.findNode("descTimer")
    m.descTimer.observeField("fire", "onDescTimer")
    m.descCache = {}
    m.heroHref = ""
    ' Trailer preview state. trailerIds: href -> YouTube id from the
    ' title page ("" when it has none); trailerUrls: href -> MP4.
    m.trailerBox = m.top.findNode("trailerBox")
    m.trailer = m.top.findNode("trailer")
    m.trailerTimer = m.top.findNode("trailerTimer")
    m.trailerTimer.observeField("fire", "onTrailerTimer")
    m.trailer.observeField("state", "onTrailerState")
    m.trailerIds = {}
    m.trailerUrls = {}
    m.heroInfo = { title: "", year: "", kind: "" }
    m.rows.observeField("rowItemSelected", "onItemSelected")
    ' Hero mirrors the focused tile.
    m.rows.observeField("rowItemFocused", "onRowItemFocused")
    m.rows.itemComponentName = "PosterItem"
    m.rows.setFocus(true)
    ' Index of the Continue Watching row when it's present (-1 = absent).
    ' We use this in onItemSelected so tiles in that row jump straight
    ' into playback instead of opening DetailsView first.
    m.continueRowIdx = -1

    ' MainScene.focusActiveChild() calls setFocus(true) on the HomeView
    ' Group root whenever the user comes back from the top nav (e.g.
    ' presses DOWN from the nav bar). Focus then sits on this Group
    ' itself, not on the rowlist - arrows do nothing until we forward
    ' it. Observing focusedChild and bouncing self-focus down to
    ' m.rows fixes the "stuck on first poster" bug and also makes
    ' LEFT-at-col-0 (sidebar handoff in onKeyEvent) reliable.
    m.top.observeField("focusedChild", "onSelfFocusChanged")

    m.task = createObject("roSGNode", "HomeTask")
    m.task.observeField("result", "onResult")
    m.top.loading = true
    m.task.control = "RUN"
end sub

' Update the hero spotlight to whatever tile is focused in the rows.
sub onRowItemFocused()
    sel = m.rows.rowItemFocused
    if sel = invalid or sel.Count() < 2 then return
    if m.rows.content = invalid then return
    rowNode = m.rows.content.getChild(sel[0])
    if rowNode = invalid then return
    updateHero(rowNode.getChild(sel[1]))
end sub

sub updateHero(cell as Object)
    if cell = invalid then return
    poster = ""
    if cell.HDPosterUrl <> invalid then poster = cell.HDPosterUrl
    if poster <> "" then m.heroBackdrop.uri = U_TmdbImage(poster, "w1280")
    if cell.title <> invalid then m.heroTitle.text = cell.title

    parts = []
    yr = cell.shortDescriptionLine2
    if yr <> invalid and yr <> "" then parts.Push(yr)
    rt = cell.shortDescriptionLine1
    if rt <> invalid and rt <> "" then parts.Push("* " + rt)
    q = cell.releaseDate
    if q <> invalid and q <> "" and q <> "Resume" then parts.Push(q)
    k = U_GetCellKind(cell)
    if k = "tv" then
        parts.Push("TV Series")
    else if k = "movie" then
        parts.Push("Movie")
    end if
    meta = ""
    for i = 0 to parts.Count() - 1
        if i > 0 then meta = meta + "   -   "
        meta = meta + parts[i]
    end for
    m.heroMeta.text = meta

    ' Synopsis. Cards do not carry one, so it comes from the title's own
    ' page: cached per title, and only requested once the cursor has
    ' rested on a tile so scrolling a row does not fire a fetch per tile.
    href = ""
    if cell.url <> invalid then href = cell.url
    m.heroHref = href
    m.descTimer.control = "stop"
    stopTrailer()
    m.heroInfo = { title: "", year: "", kind: k }
    if cell.title <> invalid then m.heroInfo.title = cell.title
    if yr <> invalid then m.heroInfo.year = yr
    if href <> "" and m.descCache.DoesExist(href) then
        m.heroDesc.text = m.descCache[href]
        m.trailerTimer.control = "start"
    else
        m.heroDesc.text = ""
        if href <> "" then m.descTimer.control = "start"
    end if
end sub

sub onDescTimer()
    if m.heroHref = "" then return
    if m.descTask <> invalid then
        m.descTask.unobserveField("result")
        m.descTask.control = "STOP"
    end if
    m.descTask = createObject("roSGNode", "SynopsisTask")
    m.descTask.observeField("result", "onDescResult")
    m.descTask.href = m.heroHref
    m.descTask.control = "RUN"
end sub

sub onDescResult()
    if m.descTask = invalid then return
    res = m.descTask.result
    m.descTask.unobserveField("result")
    m.descTask = invalid
    if res = invalid or res.href = invalid or res.href = "" then return
    text = ""
    if res.text <> invalid then text = res.text
    m.descCache[res.href] = text
    tid = ""
    if res.trailerId <> invalid then tid = res.trailerId
    m.trailerIds[res.href] = tid
    if res.href <> m.heroHref then return
    m.heroDesc.text = text
    m.trailerTimer.control = "start"
end sub

' --- Trailer preview ---------------------------------------------------

' Cursor has stayed on this tile: find and play its trailer.
sub onTrailerTimer()
    href = m.heroHref
    if href = "" then return
    if not U_PrefDefault("bannerTrailers", true) then return
    ' Only while the user is on the rows - not while the top bar, side
    ' menu or exit prompt has the remote.
    if not m.rows.isInFocusChain() then return
    if m.trailerUrls.DoesExist(href) then
        playTrailer(m.trailerUrls[href])
        return
    end if
    vid = ""
    if m.trailerIds.DoesExist(href) then vid = m.trailerIds[href]
    cancelTrailerTask()
    m.trailerTask = createObject("roSGNode", "TrailerTask")
    m.trailerTask.observeField("result", "onTrailerResult")
    m.trailerTask.href = href
    m.trailerTask.videoId = vid
    m.trailerTask.title = m.heroInfo.title
    m.trailerTask.year = m.heroInfo.year
    m.trailerTask.kind = m.heroInfo.kind
    m.trailerTask.control = "RUN"
end sub

sub onTrailerResult()
    if m.trailerTask = invalid then return
    res = m.trailerTask.result
    m.trailerTask.unobserveField("result")
    m.trailerTask = invalid
    if res = invalid or res.href = invalid or res.url = invalid then return
    ' An empty URL is cached too, so a title without a trailer is not
    ' looked up again every time the cursor passes over it.
    m.trailerUrls[res.href] = res.url
    if res.href = m.heroHref and m.rows.isInFocusChain() then playTrailer(res.url)
end sub

sub playTrailer(url as String)
    if url = "" then return
    cn = createObject("roSGNode", "ContentNode")
    cn.url = url
    cn.streamFormat = "mp4"
    cn.live = false
    cn.httpCertificatesFile = "common:/certs/ca-bundle.crt"
    m.trailerPlaying = true
    m.trailerBox.visible = true
    m.trailer.content = cn
    m.trailer.control = "play"
end sub

sub onSuspend()
    stopTrailer()
    m.descTimer.control = "stop"
end sub

sub cancelTrailerTask()
    if m.trailerTask = invalid then return
    m.trailerTask.unobserveField("result")
    m.trailerTask.control = "STOP"
    m.trailerTask = invalid
end sub

sub stopTrailer()
    m.trailerTimer.control = "stop"
    cancelTrailerTask()
    m.trailerBox.visible = false
    if m.trailerPlaying = true then
        m.trailerPlaying = false
        m.trailer.control = "stop"
    end if
end sub

' Trailer ended or could not be played: put the banner art back. A failed
' URL is forgotten so the next visit fetches a fresh one (they expire).
sub onTrailerState()
    s = m.trailer.state
    if s <> "finished" and s <> "error" then return
    if m.trailerPlaying <> true then return
    if s = "error" and m.heroHref <> "" then m.trailerUrls.Delete(m.heroHref)
    m.trailerPlaying = false
    m.trailerBox.visible = false
    m.trailer.control = "stop"
end sub

sub onSelfFocusChanged()
    fc = m.top.focusedChild
    if fc = invalid then return
    if not fc.isSameNode(m.top) then return
    ' Don't try to bounce focus before the rowlist has any content -
    ' setFocus on an empty RowList is a no-op and we'd fire a second
    ' focusedChild change for nothing. After content arrives onResult
    ' calls setFocus directly anyway.
    if m.rows = invalid or m.rows.content = invalid then return
    m.rows.setFocus(true)
end sub

sub onResult()
    bundle = m.task.result
    m.top.loading = false
    if bundle = invalid or bundle.rows = invalid or bundle.rows.Count() = 0 then
        m.hero.visible = false
        m.empty.text = "Failed to load - press OK to retry, or * to search."
        m.empty.visible = true
        m.empty.focusable = true
        ' Only steal focus to the retry label if the user is still
        ' inside HomeView. If they've navigated up to the nav bar or
        ' opened the side menu while we were loading, leave them alone.
        if m.top.isInFocusChain() then m.empty.setFocus(true)
        return
    end if
    rows = bundle.rows

    rootContent = createObject("roSGNode", "ContentNode")
    m.continueRowIdx = -1

    ' "Continue Watching" goes first when the user has anything in
    ' progress. Tiles drop the user straight into MirrorPicker for the
    ' resume target so they don't have to click through DetailsView.
    ' Stash the raw in-progress records keyed by tile column index so
    ' onItemSelected can hand the ResumePicker the full context
    ' (mirror link, episode slug, exact position) without re-reading
    ' the registry.
    m.continueRecords = []
    inProg = W_ListInProgress(20)
    if inProg <> invalid and inProg.Count() > 0 then
        m.continueRowIdx = rootContent.getChildCount()
        cwRow = rootContent.createChild("ContentNode")
        cwRow.title = "Continue Watching"
        for each ip in inProg
            cell = cwRow.createChild("ContentNode")
            cell.title = ip.title
            cell.HDPosterUrl = ip.poster
            cell.SDPosterUrl = ip.poster
            ' Subtitle: episode tag for TV, time-left for movies.
            if ip.kind = "tv" and ip.season <> invalid and ip.episode <> invalid then
                cell.shortDescriptionLine2 = "S" + ip.season.ToStr() + "E" + ip.episode.ToStr()
            else
                cell.shortDescriptionLine2 = W_FormatTime(ip.pos) + " in"
            end if
            cell.releaseDate = "Resume"
            cell.id = ip.itemKey
            U_SetCellKind(cell, ip.kind)
            cell.url = ip.href
            U_SetCellPct(cell, ip.pct)
            m.continueRecords.Push(ip)
        end for
    end if

    ' Favorites tucked under Continue Watching so the user's manually
    ' starred titles are also one click from home.
    favs = W_ListFavorites()
    if favs <> invalid and favs.Count() > 0 then
        favRow = rootContent.createChild("ContentNode")
        favRow.title = "My List"
        for each fv in favs
            cell = favRow.createChild("ContentNode")
            if fv.title <> invalid then cell.title = fv.title
            if fv.poster <> invalid then
                cell.HDPosterUrl = fv.poster
                cell.SDPosterUrl = fv.poster
            end if
            if fv.kind <> invalid then U_SetCellKind(cell, fv.kind)
            if fv.href <> invalid then cell.url = fv.href
            if fv.itemKey <> invalid then cell.id = fv.itemKey
            ' Show resume bar on My List tiles too if they have progress.
            U_SetCellPct(cell, W_GetProgressPct(fv.imdb, fv.href, 0, 0))
        end for
    end if

    for each row in rows
        rowNode = rootContent.createChild("ContentNode")
        rowNode.title = row.title
        for each item in row.items
            cell = rowNode.createChild("ContentNode")
            cell.title = item.title
            cell.HDPosterUrl = item.poster
            cell.SDPosterUrl = item.poster
            cell.shortDescriptionLine1 = item.rating
            cell.shortDescriptionLine2 = item.year
            cell.releaseDate = item.quality
            cell.id = item.id
            U_SetCellKind(cell, item.kind)
            cell.url = item.href
            U_SetCellPct(cell, W_GetProgressPct("", item.href, 0, 0))
        end for
    end for
    m.rows.content = rootContent
    m.hero.visible = true
    m.empty.visible = false
    if rootContent.getChildCount() > 0 then
        ' Back from a title: return to the tile that was opened. Rows are
        ' matched by title because Continue Watching / My List can appear
        ' or vanish between visits and shift the indexes.
        rowIdx = 0
        colIdx = 0
        a = m.top.args
        if a <> invalid and a.restore <> invalid and a.restore.col <> invalid and a.restore.rowTitle <> invalid then
            for i = 0 to rootContent.getChildCount() - 1
                if rootContent.getChild(i).title = a.restore.rowTitle then
                    rowIdx = i
                    colIdx = W_AsInt(a.restore.col)
                    exit for
                end if
            end for
        end if
        startRow = rootContent.getChild(rowIdx)
        if colIdx < 0 or colIdx >= startRow.getChildCount() then colIdx = 0
        m.rows.jumpToRowItem = [rowIdx, colIdx]
        if startRow.getChildCount() > 0 then updateHero(startRow.getChild(colIdx))
    end if
    ' Re-grab focus now that there's actually something to focus on -
    ' but only if the user is still inside HomeView. If they UPed to
    ' the nav bar or opened the side menu while we were loading, an
    ' unconditional setFocus would yank them back into the rowlist
    ' and trap them there (RowList eats LEFT at col 0, so they can't
    ' get to the side menu anymore).
    if m.top.isInFocusChain() then m.rows.setFocus(true)
end sub

' OK on the empty state retries the load.
sub retryLoad()
    m.empty.visible = false
    if m.task <> invalid then m.task.unobserveField("result")
    m.task = createObject("roSGNode", "HomeTask")
    m.task.observeField("result", "onResult")
    m.top.loading = true
    m.task.control = "RUN"
end sub

sub onItemSelected()
    sel = m.rows.rowItemSelected
    if sel = invalid then return
    rowIdx = sel[0]
    colIdx = sel[1]
    rowContent = m.rows.content.getChild(rowIdx)
    if rowContent = invalid then return
    item = rowContent.getChild(colIdx)
    if item = invalid then return
    ' The player needs the video decoder: release it before leaving.
    stopTrailer()
    m.top.viewState = { rowTitle: rowContent.title, col: colIdx }
    href = ""
    if item.url <> invalid then href = item.url
    kind = "movie"
    ' Read kind from our custom field (U_SetCellKind round-trips through
    ' addField "kind"). ContentNode.contentType silently rejects "tv" /
    ' "movie" assignments and stores an integer default in their place;
    ' comparing that int to a string with `=` throws a Type Mismatch
    ' and aborts the whole click handler - which made it look like the
    ' channel froze on every poster click.
    ckind = U_GetCellKind(item)
    if ckind = "tv" or ckind = "movie" then
        kind = ckind
    else if href <> "" and Instr(1, href, "/watchseries/") > 0 then
        kind = "tv"
    end if
    ' Continue Watching tiles open ResumePicker so the user can pick
    ' between "resume on the previous mirror", "switch mirrors", or
    ' "pick a different episode/season". DetailsView is no longer in
    ' the auto-resume hot path - going through it would double the
    ' wait (DetailsTask + ResolveTask) without giving the user any
    ' new choices.
    if rowIdx = m.continueRowIdx and m.continueRecords <> invalid and colIdx < m.continueRecords.Count() then
        ip = m.continueRecords[colIdx]
        resumeArgs = {
            kind:   ip.kind
            href:   ip.href
            imdb:   ip.imdb
            tmdb:   ip.tmdb
            title:  ip.title
            poster: ip.poster
        }
        if ip.pos <> invalid and ip.pos > 0 then resumeArgs.startPosition = ip.pos
        if ip.kind = "tv" and ip.season <> invalid and ip.episode <> invalid then
            ep = {
                season:  ip.season
                episode: ip.episode
            }
            if ip.slug <> invalid then ep.slug = ip.slug
            if ip.name <> invalid then ep.name = ip.name
            resumeArgs.episode = ep
        end if
        if ip.mirrorHost <> invalid then resumeArgs.mirrorHost = ip.mirrorHost
        if ip.mirrorLink <> invalid then resumeArgs.mirrorLink = ip.mirrorLink
        if ip.mirrorName <> invalid then resumeArgs.mirrorName = ip.mirrorName
        m.top.requestNav = {
            action: "open"
            view: "ResumePicker"
            args: resumeArgs
        }
        return
    end if

    args = {
        kind: kind
        id: item.id
        href: href
        title: item.title
        poster: item.HDPosterUrl
    }
    m.top.requestNav = {
        action: "open"
        view: "DetailsView"
        args: args
    }
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false
    if m.empty.visible and (key = "OK" or key = "play") then
        retryLoad()
        return true
    end if
    ' Star button (`*` on the Roku remote, "options" event) toggles the
    ' favorite state of the focused poster. Star indicators on every
    ' duplicate cell update via U_BumpAllCellsByUrl. We use
    ' isInFocusChain (not hasFocus) because RowList sometimes routes
    ' focus through an internal child node, leaving hasFocus() false
    ' even though the rowlist visibly owns focus.
    if key = "options" and m.rows.isInFocusChain() then
        if toggleFavoriteAtFocus() then return true
    end if
    ' LEFT-to-sidebar from RowList is gone: RowList eats LEFT at col 0
    ' silently and never bubbles. The sidebar trigger lives globally
    ' on MainScene (LEFT on the leftmost nav button).
    return false
end function

function toggleFavoriteAtFocus() as Boolean
    sel = m.rows.rowItemFocused
    if sel = invalid or sel.Count() < 2 then return false
    rowIdx = sel[0]
    colIdx = sel[1]
    rowContent = m.rows.content.getChild(rowIdx)
    if rowContent = invalid then return false
    cell = rowContent.getChild(colIdx)
    if cell = invalid then return false
    return U_ToggleFavoriteForCell(cell, m.rows.content)
end function
