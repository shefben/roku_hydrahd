' MainScene.brs - Top-level chrome + view router.

sub init()
    ' Rehydrate registry from the resolver before any view reads it. A
    ' fresh sideload after "Delete + Install" starts with an empty
    ' registry; pulling here means HomeView's Continue Watching row,
    ' FavoritesView, and search history all see prior state on first
    ' render. Pull is capped at 5s so an offline resolver can't block
    ' boot indefinitely.
    S_PullOnBoot()

    m.contentHost = m.top.findNode("contentHost")
    m.topBar = m.top.findNode("topBar")
    m.headerBar = m.top.findNode("headerBar")
    m.headerAccent = m.top.findNode("headerAccent")
    m.hint = m.top.findNode("hint")
    m.loadingBg = m.top.findNode("loadingBg")
    m.loadingGroup = m.top.findNode("loadingGroup")
    m.loadingText = m.top.findNode("loadingText")
    m.sideMenu = m.top.findNode("sideMenu")
    m.contentDefaultY = 110

    m.navTabs = [
        { id: "navHome",     view: "HomeView",      args: invalid },
        { id: "navMovies",   view: "ListView",      args: { source: "movies",  title: "Movies",   kind: "movie" } },
        { id: "navTv",       view: "ListView",      args: { source: "tv",      title: "TV Shows", kind: "tv" } },
        { id: "navTrending", view: "ListView",      args: { source: "popular", title: "Trending" } },
        { id: "navMyList",   view: "FavoritesView", args: invalid },
        { id: "navSearch",   view: "SearchView",    args: invalid }
    ]
    ' Tabs reachable from the SideMenu only - no top-bar button. Settings
    ' was pushed off the visible 1920px row, so we route it through the
    ' drawer's "Options" entry instead.
    m.offBarTabs = [
        { id: "navSettings", view: "SettingsView",  args: invalid },
        { id: "navGenres",   view: "GenresView",    args: invalid }
    ]

    m.navButtons = []
    for i = 0 to m.navTabs.Count() - 1
        btn = m.top.findNode(m.navTabs[i].id)
        m.navButtons.Push(btn)
        btn.observeField("buttonSelected", "onNavSelected")
    end for

    ' Sidebar lives on MainScene so it's reachable globally; observe its
    ' command field and dispatch.
    if m.sideMenu <> invalid then
        m.sideMenu.observeField("command", "onSideMenuCommand")
    end if

    ' Voice / OS deep-link search: main.brs sets m.top.deepLink after the
    ' scene shows; if it carries a search term we drop the user straight
    ' into Search pre-filled.
    m.top.observeField("deepLink", "onDeepLink")

    ' Exit-confirm overlay (Roku expects BACK on the home screen to exit
    ' or prompt, not silently toggle a drawer).
    m.exitDialog = m.top.findNode("exitDialog")
    m.exitChoices = m.top.findNode("exitChoices")
    if m.exitChoices <> invalid then
        m.exitChoices.buttons = ["Exit", "Cancel"]
        m.exitChoices.observeField("buttonSelected", "onExitChoice")
    end if
    m.contentFade = m.top.findNode("contentFade")

    m.activeNavIndex = 0
    m.viewStack = []
    m.activeChild = invalid

    pushView("HomeView", invalid)
    ' Park focus on the nav so the user always has a foothold even if
    ' the home view is still loading or failed to fetch.
    m.navButtons[0].setFocus(true)

    ' Auto-discover the resolver on the LAN so the user never has to
    ' type an IP. Runs in the background; if it succeeds before the
    ' user picks a mirror to play, ResolveTask will pick the new URL
    ' straight out of the registry.
    if U_PrefDefault("resolverUrl", "") = "" then startResolverDiscovery()

    ' Look for a newer build on every launch.
    m.updateDialog = m.top.findNode("updateDialog")
    m.updateText = m.top.findNode("updateText")
    m.updateTitle = m.top.findNode("updateTitle")
    m.updateChoices = m.top.findNode("updateChoices")
    m.updateChoices.observeField("buttonSelected", "onUpdateChoice")
    m.updateVersion = ""
    m.updateBusy = false
    startUpdateTask("check", "")
end sub

' --- Auto-update -------------------------------------------------------

sub startUpdateTask(mode as String, version as String)
    task = CreateObject("roSGNode", "UpdateTask")
    if task = invalid then return
    task.observeField("result", "onUpdateResult")
    task.mode = mode
    task.version = version
    task.password = U_PrefDefault("devPassword", "")
    m.updateTask = task
    task.control = "RUN"
end sub

sub onUpdateResult(event as Object)
    res = event.getData()
    m.updateTask = invalid
    if res = invalid then return
    if res.mode = "check" then
        if res.available <> true then return
        ' Never interrupt playback with the prompt; it will be offered
        ' again on the next launch.
        if m.viewStack.Count() > 0 and m.viewStack[m.viewStack.Count() - 1].name = "PlayerView" then return
        m.updateVersion = res.latest
        m.updateTitle.text = "Update available"
        m.updateText.text = "Version " + res.latest + " is available (installed: " + res.current + "). Update now, or wait until the next time the channel starts?"
        showUpdateDialog(["Update Now", "Later"])
        return
    end if
    ' Install finished without the channel being restarted under us.
    m.updateBusy = false
    if res.ok = true then
        m.updateTitle.text = "Update installed"
        m.updateText.text = "Restart the channel to use the new version."
    else
        m.updateTitle.text = "Update failed"
        m.updateText.text = res.message
    end if
    showUpdateDialog(["OK"])
end sub

sub showUpdateDialog(buttons as Object)
    m.updateChoices.buttons = buttons
    m.updateChoices.visible = true
    m.updateDialog.visible = true
    m.updateChoices.setFocus(true)
    m.updateChoices.focusButton = 0
end sub

sub closeUpdateDialog()
    m.updateDialog.visible = false
    focusActiveChild()
end sub

sub onUpdateChoice()
    idx = m.updateChoices.buttonSelected
    buttons = m.updateChoices.buttons
    if idx = invalid or buttons = invalid or idx < 0 or idx >= buttons.Count() then return
    if buttons[idx] <> "Update Now" then
        closeUpdateDialog()
        return
    end if
    if U_PrefDefault("devPassword", "") = "" then
        m.updateTitle.text = "Developer password needed"
        m.updateText.text = "To install updates the channel needs this Roku's developer (rokudev) password. Enter it under Options > Settings > Auto-Update, then restart the channel."
        showUpdateDialog(["OK"])
        return
    end if
    m.updateBusy = true
    m.updateTitle.text = "Updating to " + m.updateVersion
    m.updateText.text = "Downloading and installing. The channel will restart by itself when it is done."
    m.updateChoices.visible = false
    startUpdateTask("install", m.updateVersion)
end sub

sub startResolverDiscovery()
    if m.discoverTask <> invalid then return
    task = CreateObject("roSGNode", "DiscoverTask")
    if task = invalid then return
    task.observeField("resolverUrl", "onResolverDiscovered")
    m.discoverTask = task
    task.control = "RUN"
end sub

sub onResolverDiscovered(event as Object)
    found = event.getData()
    if found <> invalid and found <> "" then
        U_PrefSet("resolverUrl", found)
    end if
    m.discoverTask = invalid
end sub

sub pushView(viewName as String, args as Dynamic, state = invalid as Dynamic)
    ' Clear any carry-over loading overlay from the previous view. When
    ' the user clicks a poster while HomeView is still mid-fetch (or any
    ' other transition where the outgoing view never got to set
    ' loading=false because it was destroyed first), the overlay would
    ' otherwise stay visible on top of the new view - hiding the new
    ' view's contents (e.g. DetailsView's Play/Mirror buttons) until
    ' the new view's own task completes and fires loading=false.
    setLoading(false)

    ' Let the outgoing view release anything that must not outlive it
    ' (the Home banner trailer holds the video decoder the player needs).
    if m.activeChild <> invalid and m.activeChild.hasField("suspend") then m.activeChild.suspend = true

    while m.contentHost.getChildCount() > 0
        m.contentHost.removeChildIndex(0)
    end while

    child = m.contentHost.createChild(viewName)
    ' Set args BEFORE registering the loading observer. DetailsView's
    ' onArgs fires fetchDetails which sets loading=true; we *want*
    ' MainScene to miss that first true so the partial DetailsView
    ' (title + poster + Play/Mirror buttons from args) is visible
    ' immediately while DetailsTask fills in the description in the
    ' background. The eventual loading=false from onDetailResult is
    ' a no-op against an already-hidden overlay, so the chrome stays
    ' in sync.
    ' Coming back to a view: hand it the state it saved when the user left
    ' (filter, loaded pages, cursor) as args.restore. The stack keeps the
    ' original args so a later fresh open is not affected.
    childArgs = args
    if state <> invalid then
        childArgs = {}
        if args <> invalid then childArgs.Append(args)
        childArgs.restore = state
    end if
    if childArgs <> invalid then child.args = childArgs
    child.observeField("requestNav", "onChildNavRequest")
    child.observeField("loading", "onChildLoading")
    m.activeChild = child
    m.viewStack.Push({ name: viewName, args: args })
    setChromeForView(viewName)
    updateActiveNav()
    ' Quick fade-in so view switches read as a transition, not a hard cut.
    if m.contentFade <> invalid then
        m.contentHost.opacity = 0.0
        m.contentFade.control = "stop"
        m.contentFade.control = "start"
    end if
end sub

' Highlight the nav button for the section the user is currently in (red
' brand accent) vs the others (muted), so there's a persistent "you are
' here" cue independent of which control has focus.
sub updateActiveNav()
    if m.navButtons = invalid then return
    for i = 0 to m.navButtons.Count() - 1
        if m.navButtons[i] = invalid then
            ' skip
        else if i = m.activeNavIndex then
            m.navButtons[i].textColor = "0xff5252ff"
        else
            m.navButtons[i].textColor = "0xd8d8d8ff"
        end if
    end for
end sub

sub setChromeForView(viewName as String)
    ' PlayerView wants the entire screen - hide the nav bar, hint, and
    ' move the contentHost up to (0, 0) so the Video node fills 1920x1080.
    ' Also hide the global sidebar strip on the player.
    isPlayer = (viewName = "PlayerView")
    m.topBar.visible = not isPlayer
    if m.headerBar <> invalid then m.headerBar.visible = not isPlayer
    if m.headerAccent <> invalid then m.headerAccent.visible = not isPlayer
    ' The global footer hint ("OK to select - BACK for menu - UP for top
    ' bar - * to favorite") only describes the browse grids. Detail /
    ' picker / search / settings views render their OWN footer inside
    ' contentHost (which is offset +110), so leaving the global hint on
    ' would stack two hint lines on top of each other near y=1030 (and the
    ' TV episode grid would collide with it too). Show the global hint only
    ' where it's the correct, only footer.
    usesGlobalHint = (viewName = "HomeView" or viewName = "ListView" or viewName = "FavoritesView")
    m.hint.visible = usesGlobalHint
    if m.sideMenu <> invalid then m.sideMenu.visible = not isPlayer
    if isPlayer then
        m.contentHost.translation = [0, 0]
    else
        m.contentHost.translation = [0, m.contentDefaultY]
    end if
end sub

sub focusActiveChild()
    if m.activeChild <> invalid then m.activeChild.setFocus(true)
end sub

' Views are destroyed when another opens on top of them. A view that wants
' to come back where the user left it publishes a viewState; keep it on
' that view's stack entry for popView.
sub saveActiveViewState()
    if m.activeChild = invalid or m.viewStack.Count() = 0 then return
    if not m.activeChild.hasField("viewState") then return
    st = m.activeChild.viewState
    if st = invalid or st.Count() = 0 then return
    m.viewStack[m.viewStack.Count() - 1].state = st
end sub

sub replaceView(viewName as String, args as Dynamic)
    if m.viewStack.Count() > 0 then m.viewStack.Pop()
    pushView(viewName, args)
    focusActiveChild()
end sub

sub popView()
    if m.viewStack.Count() <= 1 then return
    m.viewStack.Pop()
    prev = m.viewStack.Pop()
    pushView(prev.name, prev.args, prev.state)
    focusActiveChild()
end sub

sub onNavSelected(event as Object)
    sender = event.getRoSGNode()
    for i = 0 to m.navTabs.Count() - 1
        if m.navButtons[i].isSameNode(sender) then
            m.activeNavIndex = i
            m.viewStack = []
            pushView(m.navTabs[i].view, m.navTabs[i].args)
            focusActiveChild()
            return
        end if
    end for
end sub

sub onChildLoading(event as Object)
    flag = event.getData()
    setLoading(flag)
end sub

sub setLoading(flag as Boolean)
    m.loadingBg.visible = flag
    m.loadingGroup.visible = flag
end sub

sub onChildNavRequest(event as Object)
    payload = event.getData()
    if payload = invalid then return
    action = payload.action
    ' LEFT from the leftmost grid column bubbles up as openMenu. Reveal
    ' the side drawer directly (panel slides fully in + focus lands on
    ' its first button). Handled before the discover-cancel below so a
    ' simple menu peek doesn't tear down LAN resolver discovery.
    if action = "openMenu" then
        if m.sideMenu <> invalid and m.sideMenu.visible then
            m.sideMenu.expandRequest = true
        end if
        return
    end if
    ' DetailsTask competes with DiscoverTask's subnet scan for Roku's
    ' tight per-channel TCP socket pool (~10-15). If discover is still
    ' running when the user clicks a poster, the page fetch can stall
    ' or look frozen. Cancel discover before opening any subview - the
    ' SSDP probe path finishes in <1.5s anyway, and a missed scan just
    ' means the user falls back to a manual Settings entry or a retry.
    if m.discoverTask <> invalid then
        m.discoverTask.control = "STOP"
        m.discoverTask = invalid
    end if
    if action = "open" then
        saveActiveViewState()
        pushView(payload.view, payload.args)
        focusActiveChild()
    else if action = "replace" then
        replaceView(payload.view, payload.args)
    else if action = "back" then
        popView()
    else if action = "navTab" then
        ' SideMenu fires this to switch the user to a different top-
        ' level tab, identical to clicking that nav button.
        switchToTab(payload.tabId)
    else if action = "exit" then
        ' main.brs is observing exitRequested and returns when set.
        m.top.exitRequested = true
    end if
end sub

sub switchToTab(tabId as String)
    if tabId = "" or tabId = invalid then return
    for i = 0 to m.navTabs.Count() - 1
        if m.navTabs[i].id = tabId then
            m.activeNavIndex = i
            m.viewStack = []
            pushView(m.navTabs[i].view, m.navTabs[i].args)
            focusActiveChild()
            return
        end if
    end for
    ' Off-bar tabs (currently just Settings) have no nav button to
    ' highlight. Leave activeNavIndex pointing at the previous bar tab
    ' so UP-into-nav still lands on a valid button.
    for i = 0 to m.offBarTabs.Count() - 1
        if m.offBarTabs[i].id = tabId then
            m.viewStack = []
            pushView(m.offBarTabs[i].view, m.offBarTabs[i].args)
            focusActiveChild()
            return
        end if
    end for
end sub

' SideMenu sits at MainScene-level. Its `command` field carries the
' button the user picked: { action: "navTab", tabId: ... } /
' { action: "exit" } / { action: "collapsed" }. We dispatch directly
' rather than going through the requestNav path used by views.
sub onSideMenuCommand()
    if m.sideMenu = invalid then return
    cmd = m.sideMenu.command
    if cmd = invalid then return
    if cmd.action = "collapsed" then
        ' User dismissed the strip without picking anything - put focus
        ' back on the active view's main widget so arrows aren't dead.
        focusActiveChild()
        return
    end if
    if cmd.action = "exit" then
        m.top.exitRequested = true
        return
    end if
    if cmd.action = "navTab" then
        ' Slide the panel back out before switching tabs - otherwise it
        ' stays visible overlapping the new view's content.
        m.sideMenu.callFunc("collapseSilent", invalid)
        switchToTab(cmd.tabId)
        return
    end if
end sub

function navHasFocus() as Boolean
    for i = 0 to m.navButtons.Count() - 1
        if m.navButtons[i].hasFocus() then
            m.activeNavIndex = i
            return true
        end if
    end for
    return false
end function

sub onDeepLink()
    dl = m.top.deepLink
    if dl = invalid then return
    term = ""
    if dl.q <> invalid then term = dl.q
    if term = "" and dl.query <> invalid then term = dl.query
    if term = "" and dl.mediaType = "search" and dl.contentId <> invalid then term = dl.contentId
    if term = "" then return
    m.viewStack = []
    pushView("SearchView", { query: term })
    focusActiveChild()
end sub

sub showExitDialog()
    if m.exitDialog = invalid then
        ' No dialog available - just exit.
        m.top.exitRequested = true
        return
    end if
    m.exitDialog.visible = true
    if m.exitChoices <> invalid then
        m.exitChoices.setFocus(true)
        m.exitChoices.focusButton = 1   ' default highlight on Cancel
    end if
end sub

sub closeExitDialog()
    if m.exitDialog <> invalid then m.exitDialog.visible = false
    focusActiveChild()
end sub

sub onExitChoice()
    if m.exitChoices = invalid then return
    idx = m.exitChoices.buttonSelected
    if idx = 0 then
        m.top.exitRequested = true
    else
        closeExitDialog()
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false

    ' Exit-confirm overlay traps input while visible.
    if m.exitDialog <> invalid and m.exitDialog.visible then
        if key = "back" then
            closeExitDialog()
            return true
        end if
        return false   ' let the ButtonGroup handle left/right/OK
    end if

    ' Update prompt traps input while visible; BACK means "later" unless
    ' an install is running.
    if m.updateDialog <> invalid and m.updateDialog.visible then
        if m.updateBusy then return true
        if key = "back" then
            closeUpdateDialog()
            return true
        end if
        if key = "up" or key = "down" then return true
        return false
    end if

    ' OPTIONS (`*` on the Roku remote) is reserved for the active
    ' view: poster grids use it to toggle favorites, DetailsView uses
    ' it as a shortcut for Save-to-List. We don't intercept it here.

    if key = "back" then
        ' Standard Roku back semantics:
        '   - inside a subview (Details, MirrorPicker, ...) -> pop it
        '   - on a non-Home root tab -> return to Home
        '   - on Home root -> confirm exit
        ' The side drawer is still reachable via LEFT on the leftmost nav
        ' button and LEFT from a grid's first column, so BACK no longer
        ' needs to double as the menu toggle.
        if m.viewStack.Count() > 1 then
            popView()
            return true
        end if
        if m.activeNavIndex > 0 then
            switchToTab(m.navTabs[0].id)
            return true
        end if
        showExitDialog()
        return true
    end if

    ' Nav-bar key handling: left/right between buttons, down into content.
    if navHasFocus() then
        if key = "left" then
            if m.activeNavIndex > 0 then
                m.activeNavIndex = m.activeNavIndex - 1
                m.navButtons[m.activeNavIndex].setFocus(true)
                return true
            end if
            ' Already at the leftmost nav button - LEFT here opens the
            ' side drawer (panel expanded directly, not just the strip).
            ' Nav buttons bubble directional keys reliably; LEFT-from-
            ' RowList-col-0 does NOT bubble on Roku.
            if m.sideMenu <> invalid and m.sideMenu.visible then
                m.sideMenu.expandRequest = true
                return true
            end if
            return true
        end if
        if key = "right" then
            if m.activeNavIndex < m.navButtons.Count() - 1 then
                m.activeNavIndex = m.activeNavIndex + 1
                m.navButtons[m.activeNavIndex].setFocus(true)
            end if
            return true
        end if
        if key = "down" then
            focusActiveChild()
            return true
        end if
        return false
    end if

    ' From inside content, ^ at the top edge bubbles up here - jump to nav.
    if key = "up" then
        m.navButtons[m.activeNavIndex].setFocus(true)
        return true
    end if

    return false
end function
