' MirrorPicker.brs - Lists all servers/mirrors and resolves selection to a stream.

sub init()
    m.mirrors = []
    m.args = invalid

    ' A saved mirror to auto-resume once the FULL server list arrives (see
    ' resolveDirectMirror / onMirrorResult). Kept separate from m.args so the
    ' complete list is always fetched and shown - not just the one mirror the
    ' episode was last played on.
    m.pendingDirect = invalid

    ' Hosts we've already attempted in this picker session. Used to
    ' drive the auto-cascade ("try every mirror until one works")
    ' opt-in flow and to avoid looping back to a known-bad mirror.
    m.triedHosts = {}
    m.autoCascade = false
    m.dialog = invalid
    ' Guards against launching two ResolveTasks for one selection - see
    ' startResolveForMirror.
    m.resolveInFlight = false
    m.resolveLink = ""

    m.title = m.top.findNode("title")
    m.subtitle = m.top.findNode("subtitle")
    m.grid = m.top.findNode("mirrorGrid")
    m.status = m.top.findNode("status")
    m.grid.itemComponentName = "MirrorItem"
    m.grid.observeField("itemSelected", "onMirrorSelected")
    m.grid.setFocus(true)

    ' Bounce focus down to the mirror grid whenever MainScene refocuses
    ' the view root. Without this the user is stranded on a focusless
    ' Group after the UP-to-nav / DOWN-back dance.
    m.top.observeField("focusedChild", "onSelfFocusChanged")
end sub

sub onSelfFocusChanged()
    fc = m.top.focusedChild
    if fc = invalid then return
    if not fc.isSameNode(m.top) then return
    if m.grid <> invalid and m.grid.content <> invalid and m.grid.content.getChildCount() > 0 then
        m.grid.setFocus(true)
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false
    ' MarkupGrid swallows UP at top row in some firmwares; this handler
    ' lets the user always escape back to the top nav. Returning false
    ' bubbles to MainScene which jumps focus to the active nav button.
    if key = "up" and m.grid.hasFocus() then
        idx = m.grid.itemFocused
        if idx = invalid then idx = 0
        if idx < m.grid.numColumns then return false
    end if
    return false
end function

sub onArgs()
    a = m.top.args
    if a = invalid then return
    m.args = a
    m.title.text = a.title
    if a.episode <> invalid then
        m.subtitle.text = "S" + a.episode.season.ToStr() + "E" + a.episode.episode.ToStr() + " - " + a.episode.name
    else
        m.subtitle.text = "Movie"
    end if
    ' "Resume on previous mirror" hands us the saved embed URL so we
    ' can skip the ServersTask round-trip and go straight to resolve.
    if a.directMirror <> invalid and a.directMirror.link <> invalid and a.directMirror.link <> "" then
        resolveDirectMirror(a.directMirror)
        return
    end if
    fetchMirrors()
end sub

' A saved mirror was handed to us (Resume / replaying the same episode).
' Instead of showing ONLY that mirror, fetch the full server list so every
' mirror stays visible and selectable, then auto-resume the saved one from
' that list (onMirrorResult). Slightly slower to first frame than jumping
' straight to the saved link, but the user keeps all their alternatives on
' screen and can switch at any time.
sub resolveDirectMirror(dm as Object)
    m.pendingDirect = dm
    m.status.text = "Loading mirrors..."
    fetchMirrors()
end sub

' Fallback for when the server list can't be fetched at all (empty result):
' synthesize a single-row grid from the saved mirror and resolve it directly
' so resume still works with no fresh list. The onResolved failure path
' re-tries a full fetch if this saved link turns out to be dead.
sub resolveSavedMirrorOnly(dm as Object)
    name = ""
    if dm.name <> invalid then name = dm.name
    host = ""
    if dm.host <> invalid then host = dm.host
    if name = "" then name = host
    mirror = {
        id: ""
        name: name
        link: dm.link
        host: host
        qualityHint: ""
        isPremium: false
    }
    m.mirrors = [mirror]
    root = createObject("roSGNode", "ContentNode")
    cell = root.createChild("ContentNode")
    cell.title = name
    cell.shortDescriptionLine1 = host
    cell.shortDescriptionLine2 = "Resuming..."
    m.grid.content = root
    m.grid.itemSelected = 0
    onMirrorSelected()
end sub

' Ensure the saved mirror exists in m.mirrors and return its index. Matches
' by host so we resume on the same provider using its FRESH link; if the
' host has rotated out of the current list we append the saved mirror (with
' its saved link) so it's still both playable and visible.
function ensureSavedMirrorPresent(dm as Object) as Integer
    wantHost = ""
    if dm.host <> invalid then wantHost = LCase(dm.host)
    if wantHost <> "" then
        for i = 0 to m.mirrors.Count() - 1
            mh = ""
            if m.mirrors[i].host <> invalid then mh = LCase(m.mirrors[i].host)
            if mh = wantHost then return i
        end for
    end if
    name = ""
    if dm.name <> invalid then name = dm.name
    if name = "" then name = dm.host
    m.mirrors.Push({
        id: ""
        name: name
        link: dm.link
        host: dm.host
        qualityHint: ""
        isPremium: false
    })
    return m.mirrors.Count() - 1
end function

sub fetchMirrors()
    m.top.loading = true
    if m.task <> invalid then m.task.unobserveField("result")
    m.task = createObject("roSGNode", "ServersTask")
    m.task.observeField("result", "onMirrorResult")
    m.task.kind = m.args.kind
    m.task.imdb = m.args.imdb
    m.task.tmdb = m.args.tmdb
    m.task.refer = m.args.href
    if m.args.episode <> invalid then
        m.task.season = m.args.episode.season
        m.task.episode = m.args.episode.episode
        m.task.slug = m.args.episode.slug
    end if
    m.task.control = "RUN"
end sub

sub onMirrorResult()
    res = m.task.result
    m.top.loading = false
    ' Episode discovery supplies numeric IDs even when TMDB enrichment is off.
    ' Keep href as the series key for progress; use the episode as HTTP referer.
    if res <> invalid then
        if res.tmdb <> invalid and res.tmdb <> "" then m.args.tmdb = res.tmdb
        if res.imdb <> invalid and res.imdb <> "" then m.args.imdb = res.imdb
        if res.refer <> invalid and res.refer <> "" then m.args.resolveRefer = res.refer
    end if
    if res = invalid or res.mirrors = invalid or res.mirrors.Count() = 0 then
        ' Empty list. If we were auto-resuming a saved mirror, fall back to
        ' playing just that one so resume still works; otherwise there is
        ' genuinely nothing to offer.
        if m.pendingDirect <> invalid then
            dm = m.pendingDirect
            m.pendingDirect = invalid
            resolveSavedMirrorOnly(dm)
            return
        end if
        m.status.text = "No mirrors available."
        return
    end if
    m.mirrors = sortMirrorsByScore(res.mirrors)

    ' Auto-resuming a saved mirror: make sure it's in the list (append it if
    ' its host rotated out) BEFORE we build the grid so every mirror -
    ' including the saved one - is visible and selectable.
    directIdx = -1
    if m.pendingDirect <> invalid then
        directIdx = ensureSavedMirrorPresent(m.pendingDirect)
    end if
    root = createObject("roSGNode", "ContentNode")
    for each mr in m.mirrors
        cell = root.createChild("ContentNode")
        cell.title = mr.name
        cell.shortDescriptionLine1 = mr.host
        ' Stack quality hint and reliability badge into line 2.
        line2 = ""
        if mr.qualityHint <> invalid and mr.qualityHint <> "" then line2 = mr.qualityHint
        scoreLabel = mirrorScoreLabel(mr.host)
        if scoreLabel <> "" then
            if line2 <> "" then line2 = line2 + "  -  "
            line2 = line2 + scoreLabel
        end if
        cell.shortDescriptionLine2 = line2
        if mr.isPremium then cell.releaseDate = "premium"
    end for
    m.grid.content = root
    m.grid.setFocus(true)
    m.status.text = m.mirrors.Count().ToStr() + " mirrors loaded - top-ranked first."

    ' Saved-mirror auto-resume: kick off the mirror the episode was last
    ' played on while leaving the WHOLE list on screen so the user can switch
    ' at any time. Focus lands on that mirror so the highlight matches what's
    ' about to play.
    if m.pendingDirect <> invalid and directIdx >= 0 then
        m.pendingDirect = invalid
        m.grid.jumpToItem = directIdx
        m.status.text = "Resuming on " + m.mirrors[directIdx].host + "..."
        startResolveForMirror(m.mirrors[directIdx])
        return
    end if
    m.pendingDirect = invalid

    ' Caller (DetailsView Resume button, ResumePicker, etc.) can hint at
    ' a previously-used mirror host. If we find a match in the freshly
    ' fetched list we kick off resolve straight away - same UX as
    ' "Resume on previous mirror" but for cases where the saved embed
    ' URL is for a different episode and can't be replayed verbatim.
    if m.args <> invalid and m.args.preferredMirrorHost <> invalid and m.args.preferredMirrorHost <> "" then
        wantHost = LCase(m.args.preferredMirrorHost)
        for i = 0 to m.mirrors.Count() - 1
            mh = ""
            if m.mirrors[i].host <> invalid then mh = LCase(m.mirrors[i].host)
            if mh = wantHost then
                m.status.text = "Resuming on " + m.mirrors[i].host + "..."
                startResolveForMirror(m.mirrors[i])
                return
            end if
        end for
    end if
    if m.args <> invalid and m.args.autoPick = true then
        m.grid.itemSelected = 0
        onMirrorSelected()
    end if
end sub

' Sort by reliability ratio descending; mirrors we have no data on
' bubble between known-good and known-bad so the user still discovers
' them. Stable sort via simple insertion to keep equal-score mirrors
' in original (server-provided) order.
function sortMirrorsByScore(mirrors as Object) as Object
    n = mirrors.Count()
    if n <= 1 then return mirrors
    ranked = []
    for i = 0 to n - 1
        host = ""
        if mirrors[i].host <> invalid then host = mirrors[i].host
        ratio = W_MirrorScore(host)
        ' Mirrors with no history get a neutral 0.5 so they aren't
        ' punished for being new but don't beat proven-reliable ones.
        if ratio < 0 then ratio = 0.5
        ranked.Push({ idx: i, ratio: ratio, total: W_MirrorTotal(host) })
    end for
    for i = 1 to ranked.Count() - 1
        cur = ranked[i]
        j = i - 1
        while j >= 0
            higher = (ranked[j].ratio < cur.ratio) or (ranked[j].ratio = cur.ratio and ranked[j].total < cur.total)
            if not higher then exit while
            ranked[j + 1] = ranked[j]
            j = j - 1
        end while
        ranked[j + 1] = cur
    end for
    out = []
    for each r in ranked
        out.Push(mirrors[r.idx])
    end for
    return out
end function

function mirrorScoreLabel(host as String) as String
    rec = W_MirrorRecord(host)
    total = rec.ok + rec.fail
    if total = 0 then return ""
    ratio = rec.ok / (total * 1.0)
    pct = Int(ratio * 100)
    return pct.ToStr() + "% (" + rec.ok.ToStr() + "/" + total.ToStr() + ")"
end function

sub onMirrorSelected()
    idx = m.grid.itemSelected
    if idx = invalid or idx < 0 or idx >= m.mirrors.Count() then return
    startResolveForMirror(m.mirrors[idx])
end sub

' Kick off ResolveTask against a specific mirror dict. Called both
' from the grid observer and from tryNextUntried() during auto-cascade
' so we don't depend on grid.itemSelected (which can double-fire the
' observer when set programmatically to a new value).
sub startResolveForMirror(mirror as Object)
    if mirror = invalid then return
    ' Coalesce duplicate triggers. Setting m.grid.itemSelected fires the
    ' itemSelected observer (onMirrorSelected) AND several callers then
    ' also call onMirrorSelected() explicitly, so this runs twice for one
    ' selection. Two ResolveTasks would each hammer the mirror CDN with a
    ' full enrichment probe-burst back-to-back, draining its per-IP rate
    ' budget so Roku's first segment fetches get 429'd and the stream
    ' dies with a fatal error a second in. Skip if a resolve for this
    ' exact link is already in flight.
    if m.resolveInFlight = true and m.resolveLink = mirror.link then return
    m.activeMirror = mirror
    if mirror.host <> invalid and mirror.host <> "" then
        m.triedHosts[mirror.host] = true
    end if
    m.status.text = "Resolving stream from " + mirror.host + "..."
    m.top.loading = true
    ' Unobserve AND stop the previous task - unobserve alone leaves it
    ' running (control=RUN was already sent), so it keeps hitting the CDN.
    if m.resolve <> invalid then
        m.resolve.unobserveField("result")
        m.resolve.control = "STOP"
    end if
    m.resolveInFlight = true
    m.resolveLink = mirror.link
    m.resolve = createObject("roSGNode", "ResolveTask")
    m.resolve.observeField("result", "onResolved")
    m.resolve.embedUrl = mirror.link
    m.resolve.refer = m.args.href
    if m.args.resolveRefer <> invalid then m.resolve.refer = m.args.resolveRefer
    m.resolve.kind = m.args.kind
    m.resolve.imdb = m.args.imdb
    m.resolve.tmdb = m.args.tmdb
    if m.args.episode <> invalid then
        m.resolve.season = m.args.episode.season
        m.resolve.episode = m.args.episode.episode
    end if
    m.resolve.control = "RUN"
end sub

sub onResolved()
    res = m.resolve.result
    m.top.loading = false
    ' Resolve finished - clear the in-flight guard so the user can retry
    ' this same mirror later (see startResolveForMirror).
    m.resolveInFlight = false
    if res = invalid or res.url = invalid or res.url = "" then
        ' Mark this host as a failed resolve so the next visit ranks it
        ' below mirrors that are still working.
        if m.activeMirror <> invalid then W_RecordMirrorOutcome(m.activeMirror.host, false)
        ' "Resume on previous mirror" puts a single-row grid on screen.
        ' If that mirror is dead now, "try another" is a lie - there's
        ' no other entry to pick. Fall back to a full server list so
        ' the user actually has alternatives.
        if m.args <> invalid and m.args.directMirror <> invalid and m.mirrors.Count() <= 1 then
            m.args.directMirror = invalid
            m.status.text = "Saved mirror is no longer working - loading other mirrors..."
            fetchMirrors()
            return
        end if
        ' If the user already opted into auto-cascade, silently move on
        ' to the next untried mirror. If we exhaust the list (or there
        ' was nothing else to try) admit defeat with a clear message.
        if m.autoCascade then
            if tryNextUntried() then return
            m.autoCascade = false
            m.status.text = "Some mirrors failed - pick any one to try it again."
            restoreGridFocus()
            return
        end if
        ' First failure: offer the cascade once, only if there are other
        ' mirrors we haven't tried yet. Otherwise we'd be promising
        ' something we can't deliver.
        if hasUntriedMirror() then
            promptAutoCascade()
            return
        end if
        m.status.text = "That mirror failed - pick another from the list."
        restoreGridFocus()
        return
    end if
    if m.activeMirror <> invalid then W_RecordMirrorOutcome(m.activeMirror.host, true)
    referer = ""
    if res.referer <> invalid then referer = res.referer
    userAgent = ""
    if res.userAgent <> invalid then userAgent = res.userAgent
    playerArgs = {
        title: m.args.title
        subtitle: m.subtitle.text
        url: res.url
        streamFormat: res.streamFormat
        qualities: res.qualities
        subtitles: res.subtitles
        poster: m.args.poster
        referer: referer
        userAgent: userAgent
        kind: m.args.kind
        imdb: m.args.imdb
        tmdb: m.args.tmdb
        href: m.args.href
    }
    if m.args.episodeQueue <> invalid then
        playerArgs.episodeQueue = m.args.episodeQueue
        playerArgs.episodeQueueIndex = m.args.episodeQueueIndex
    end if
    if m.args.episode <> invalid then playerArgs.episode = m.args.episode
    if m.args.startPosition <> invalid then playerArgs.startPosition = m.args.startPosition
    if res.leadSkip <> invalid then playerArgs.leadSkip = res.leadSkip
    if m.activeMirror <> invalid then
        if m.activeMirror.host <> invalid then playerArgs.mirrorHost = m.activeMirror.host
        ' mirrorLink + mirrorName are persisted in saveProgress so the
        ' Continue Watching ResumePicker can offer "Resume on <host>"
        ' without re-fetching the server list.
        if m.activeMirror.link <> invalid then playerArgs.mirrorLink = m.activeMirror.link
        if m.activeMirror.name <> invalid then playerArgs.mirrorName = m.activeMirror.name
    end if
    if res.chapters <> invalid then playerArgs.chapters = res.chapters
    payload = {
        action: "replace"
        view: "PlayerView"
        args: playerArgs
    }
    m.top.requestNav = payload
end sub

' True iff there's at least one mirror in the current list whose host
' we haven't already attempted in this session. Hosts are deduplicated
' (some pages list the same upstream under multiple labels) so a single
' failure also counts the duplicates as tried.
function hasUntriedMirror() as Boolean
    if m.mirrors = invalid then return false
    for i = 0 to m.mirrors.Count() - 1
        host = ""
        if m.mirrors[i].host <> invalid then host = m.mirrors[i].host
        if host = "" or not m.triedHosts.DoesExist(host) then return true
    end for
    return false
end function

' Pick the first untried mirror, mark it active, and kick off resolve.
' Returns false if the list has been exhausted (caller should surface
' the "all mirrors failing" message). We avoid touching
' grid.itemSelected here so we don't accidentally fire the grid
' observer (which would race against startResolveForMirror).
function tryNextUntried() as Boolean
    if m.mirrors = invalid then return false
    for i = 0 to m.mirrors.Count() - 1
        host = ""
        if m.mirrors[i].host <> invalid then host = m.mirrors[i].host
        if host = "" or not m.triedHosts.DoesExist(host) then
            startResolveForMirror(m.mirrors[i])
            return true
        end if
    end for
    return false
end function

' Standard Roku Dialog asking the user whether to auto-iterate through
' remaining mirrors. The dialog is parented to the scene's `dialog`
' field so it floats over the picker and grabs focus. Picking Yes flips
' m.autoCascade and starts the iteration; No leaves the user on the
' grid with the "try another" hint.
sub promptAutoCascade()
    dlg = createObject("roSGNode", "Dialog")
    dlg.title = "Mirror failed"
    dlg.message = "This mirror could not be loaded. Try the remaining mirrors automatically until one works?"
    dlg.buttons = ["Yes, try the rest", "No"]
    dlg.observeField("buttonSelected", "onCascadeDialogButton")
    m.dialog = dlg
    m.top.getScene().dialog = dlg
end sub

sub onCascadeDialogButton()
    if m.dialog = invalid then return
    idx = m.dialog.buttonSelected
    m.dialog.close = true
    m.dialog = invalid
    if idx = 0 then
        m.autoCascade = true
        m.status.text = "Trying remaining mirrors..."
        if not tryNextUntried() then
            m.autoCascade = false
            m.status.text = "Some mirrors failed - pick any one to try it again."
            restoreGridFocus()
        end if
    else
        m.status.text = "Pick any mirror from the list to try it."
        restoreGridFocus()
    end if
end sub

' Return focus to the mirror grid after a dialog or a failed resolve so
' the user can always move through and re-pick mirrors. Every mirror
' stays in the list - nothing is ever removed, even after it fails - so
' the user can retry a partially-working mirror or choose a different
' one. Without this the grid can be left focusless after a Dialog closes
' and arrow keys / OK do nothing.
sub restoreGridFocus()
    if m.grid <> invalid and m.grid.content <> invalid and m.grid.content.getChildCount() > 0 then
        m.grid.setFocus(true)
    end if
end sub
