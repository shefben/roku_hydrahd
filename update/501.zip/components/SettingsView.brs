' SettingsView.brs - Base URL, resolver URL, default CC styling.

sub init()
    m.baseUrlValue = m.top.findNode("baseUrlValue")
    m.resolverValue = m.top.findNode("resolverValue")
    m.ccPreview = m.top.findNode("ccPreview")
    m.ccPreviewBg = m.top.findNode("ccPreviewBg")
    m.urlEditGroup = m.top.findNode("urlEditGroup")
    m.urlEditTitle = m.top.findNode("urlEditTitle")
    m.urlKb = m.top.findNode("urlKb")
    m.layoutGroup = m.top.findNode("layoutGroup")
    m.layoutGroupBaseY = 80

    ' Each row is its own ButtonGroup so left/right works inside the row.
    ' We track the rows in display order so onKeyEvent can move focus
    ' up/down between them.
    m.baseRow = m.top.findNode("baseRow")
    m.baseRow.buttons = ["Use hydrahd.gd", "Edit URL"]
    m.baseRow.observeField("buttonSelected", "onBaseRowSelected")

    m.tmdbValue = m.top.findNode("tmdbValue")
    m.tmdbRow = m.top.findNode("tmdbRow")
    m.tmdbRow.buttons = ["Set Key...", "Clear"]
    m.tmdbRow.observeField("buttonSelected", "onTmdbRowSelected")

    m.inChannelValue = m.top.findNode("inChannelValue")
    m.inChannelRow = m.top.findNode("inChannelRow")
    m.inChannelRow.buttons = ["Off", "On"]
    m.inChannelRow.observeField("buttonSelected", "onInChannelRowSelected")

    m.resolverRow = m.top.findNode("resolverRow")
    m.resolverRow.buttons = ["Auto-discover", "Set Manually...", "Clear"]
    m.resolverRow.observeField("buttonSelected", "onResolverRowSelected")
    m.resolverStatus = m.top.findNode("resolverStatus")
    m.resolverStatus.text = ""

    m.qualityRow = m.top.findNode("qualityRow")
    m.qualityRow.buttons = ["Best", "1080p", "720p", "Data Saver"]
    m.qualityRow.observeField("buttonSelected", "onQualitySelected")

    m.trailerValue = m.top.findNode("trailerValue")
    m.trailerRow = m.top.findNode("trailerRow")
    m.trailerRow.buttons = ["Off", "On"]
    m.trailerRow.observeField("buttonSelected", "onTrailerRowSelected")

    m.updateValue = m.top.findNode("updateValue")
    m.updateRow = m.top.findNode("updateRow")
    m.updateRow.buttons = ["Set Password...", "Clear"]
    m.updateRow.observeField("buttonSelected", "onUpdateRowSelected")

    m.ccSizeRow = m.top.findNode("ccSizeRow")
    m.ccSizeRow.buttons = ["Text: Small", "Text: Medium", "Text: Large"]
    m.ccSizeRow.observeField("buttonSelected", "onCcSizeSelected")

    m.ccColorRow = m.top.findNode("ccColorRow")
    m.ccColorRow.buttons = ["Text: White", "Text: Yellow", "Text: Cyan"]
    m.ccColorRow.observeField("buttonSelected", "onCcColorSelected")

    m.ccBgRow = m.top.findNode("ccBgRow")
    m.ccBgRow.buttons = ["BG: Black", "BG: Semi-Transparent", "BG: None"]
    m.ccBgRow.observeField("buttonSelected", "onCcBgSelected")

    m.urlActionsRow = m.top.findNode("urlActionsRow")
    m.urlActionsRow.buttons = ["Save", "Cancel"]
    m.urlActionsRow.observeField("buttonSelected", "onUrlActionsSelected")

    m.rowOrder = [m.baseRow, m.tmdbRow, m.inChannelRow, m.resolverRow, m.qualityRow, m.trailerRow, m.updateRow, m.ccSizeRow, m.ccColorRow, m.ccBgRow]
    m.currentRow = 0

    m.editTarget = ""
    m.baseRow.setFocus(true)

    refresh()

    ' Same focus-redirect pattern as the poster views: when MainScene
    ' re-focuses the SettingsView root (e.g. after UP-to-nav / DOWN-back)
    ' bounce focus down to the first row so the arrow keys do something.
    ' If the URL keyboard is open we land on it instead, so the user
    ' doesn't lose their typing.
    m.top.observeField("focusedChild", "onSelfFocusChanged")
end sub

sub onSelfFocusChanged()
    fc = m.top.focusedChild
    if fc = invalid then return
    if not fc.isSameNode(m.top) then return
    if m.urlEditGroup <> invalid and m.urlEditGroup.visible then
        m.urlKb.setFocus(true)
        return
    end if
    m.baseRow.setFocus(true)
    m.currentRow = 0
end sub

sub refresh()
    m.baseUrlValue.text = U_NormalizeBaseUrl(U_PrefDefault("baseUrl", U_DefaultBaseUrl()))
    r = U_PrefDefault("resolverUrl", U_DefaultResolverUrl())
    if r = "" then r = "(not set - falls back to best-effort scrape)"
    m.resolverValue.text = r
    tk = U_PrefDefault("tmdbKey", "")
    if tk = "" then
        m.tmdbValue.text = "(not set - showing HydraHD info only)"
        m.tmdbValue.color = "0xc8c8c8ff"
    else
        m.tmdbValue.text = "Key set (ends ..." + Right(tk, 4) + ") - rich metadata on"
        m.tmdbValue.color = "0x9affa0ff"
    end if
    if U_PrefDefault("inChannelResolve", true) then
        m.inChannelValue.text = "Currently: ON - try resolving every mirror in-channel first."
        m.inChannelValue.color = "0x9affa0ff"
    else
        m.inChannelValue.text = "Currently: OFF - use the external resolver URL below."
        m.inChannelValue.color = "0xc8c8c8ff"
    end if
    if U_PrefDefault("bannerTrailers", true) then
        m.trailerValue.text = "Currently: ON - the highlighted title's trailer plays (with sound) on the Home banner."
        m.trailerValue.color = "0x9affa0ff"
    else
        m.trailerValue.text = "Currently: OFF - the Home banner shows artwork only."
        m.trailerValue.color = "0xc8c8c8ff"
    end if
    ver = CreateObject("roAppInfo").GetValue("update_version")
    if U_PrefDefault("devPassword", "") = "" then
        m.updateValue.text = "Installed version " + ver + " - password not set, updates can be offered but not installed."
        m.updateValue.color = "0xc8c8c8ff"
    else
        m.updateValue.text = "Installed version " + ver + " - password saved, updates can install."
        m.updateValue.color = "0x9affa0ff"
    end if
    paintCcPreview()
end sub

sub onUpdateRowSelected()
    if m.updateRow.buttonSelected = 0 then
        openUrlEditor("devPassword", "Enter this Roku's developer (rokudev) password", U_PrefDefault("devPassword", ""))
    else
        U_PrefSet("devPassword", "")
        refresh()
    end if
end sub

sub onTrailerRowSelected()
    if m.trailerRow.buttonSelected = 0 then
        U_PrefSet("bannerTrailers", "false")
    else
        U_PrefSet("bannerTrailers", "true")
    end if
    refresh()
end sub

sub onInChannelRowSelected()
    idx = m.inChannelRow.buttonSelected
    if idx = 0 then
        U_PrefSet("inChannelResolve", "false")
    else if idx = 1 then
        U_PrefSet("inChannelResolve", "true")
    end if
    refresh()
end sub

sub onBaseRowSelected()
    idx = m.baseRow.buttonSelected
    if idx = 0 then
        U_PrefSet("baseUrl", U_DefaultBaseUrl())
        refresh()
    else if idx = 1 then
        openUrlEditor("baseUrl", "Edit base URL", U_NormalizeBaseUrl(U_PrefDefault("baseUrl", U_DefaultBaseUrl())))
    end if
end sub

sub onTmdbRowSelected()
    idx = m.tmdbRow.buttonSelected
    if idx = 0 then
        openUrlEditor("tmdbKey", "Enter TMDB v3 API key (themoviedb.org -> Settings -> API)", U_PrefDefault("tmdbKey", ""))
    else if idx = 1 then
        U_PrefSet("tmdbKey", "")
        refresh()
    end if
end sub

sub onResolverRowSelected()
    idx = m.resolverRow.buttonSelected
    if idx = 0 then
        startDiscovery()
    else if idx = 1 then
        openUrlEditor("resolverUrl", "Edit resolver URL (e.g. http://192.168.1.50:8787)", U_PrefDefault("resolverUrl", U_DefaultResolverUrl()))
    else if idx = 2 then
        U_PrefSet("resolverUrl", "")
        refresh()
        m.resolverStatus.text = ""
    end if
end sub

sub startDiscovery()
    if m.discoverTask <> invalid then return
    task = CreateObject("roSGNode", "DiscoverTask")
    if task = invalid then
        m.resolverStatus.text = "Discovery unavailable on this device."
        m.resolverStatus.color = "0xff8a8aff"
        return
    end if
    m.discoverTask = task
    task.observeField("resolverUrl", "onDiscoverDone")
    m.resolverStatus.text = "Searching the LAN for a resolver..."
    m.resolverStatus.color = "0xc8c8c8ff"
    task.control = "RUN"
end sub

sub onDiscoverDone(event as Object)
    found = event.getData()
    method = ""
    if m.discoverTask <> invalid then method = m.discoverTask.method
    m.discoverTask = invalid
    if found <> invalid and found <> "" then
        U_PrefSet("resolverUrl", found)
        label = "Found resolver at " + found
        if method = "ssdp" then label = label + " (broadcast)"
        if method = "scan" then label = label + " (scan)"
        m.resolverStatus.text = label
        m.resolverStatus.color = "0x9affa0ff"
        refresh()
    else
        m.resolverStatus.text = "No resolver found. Use 'Set Manually...' to enter the URL."
        m.resolverStatus.color = "0xff8a8aff"
    end if
end sub

sub openUrlEditor(target as String, title as String, initial as Dynamic)
    m.editTarget = target
    m.urlEditTitle.text = title
    if initial = invalid then initial = ""
    m.urlKb.text = initial
    m.urlEditGroup.visible = true
    m.urlKb.setFocus(true)
end sub

sub onUrlActionsSelected()
    idx = m.urlActionsRow.buttonSelected
    if idx = 0 then
        val = U_Trim(m.urlKb.text)
        if val = invalid then val = ""
        if m.editTarget = "baseUrl" then val = U_NormalizeBaseUrl(val)
        U_PrefSet(m.editTarget, val)
        m.urlEditGroup.visible = false
        refresh()
        m.baseRow.setFocus(true)
        m.currentRow = 0
    else if idx = 1 then
        m.urlEditGroup.visible = false
        m.baseRow.setFocus(true)
        m.currentRow = 0
    end if
end sub

sub onQualitySelected()
    idx = m.qualityRow.buttonSelected
    val = "best"
    if idx = 1 then val = "1080"
    if idx = 2 then val = "720"
    if idx = 3 then val = "saver"
    U_PrefSet("videoQuality", val)
    m.qualityValue = m.top.findNode("qualityValue")
    if m.qualityValue <> invalid then
        m.qualityValue.text = "Current: " + m.qualityRow.buttons[idx]
        m.qualityValue.color = "0x9affa0ff"
    end if
end sub

sub onCcSizeSelected()
    reg = CreateObject("roRegistrySection", "HydraHD")
    idx = m.ccSizeRow.buttonSelected
    if idx = 0 then reg.Write("ccTextSize", "small")
    if idx = 1 then reg.Write("ccTextSize", "medium")
    if idx = 2 then reg.Write("ccTextSize", "large")
    reg.Flush()
    paintCcPreview()
end sub

sub onCcColorSelected()
    reg = CreateObject("roRegistrySection", "HydraHD")
    idx = m.ccColorRow.buttonSelected
    if idx = 0 then reg.Write("ccTextColor", "0xffffff")
    if idx = 1 then reg.Write("ccTextColor", "0xffd24a")
    if idx = 2 then reg.Write("ccTextColor", "0x66e5ff")
    reg.Flush()
    paintCcPreview()
end sub

sub onCcBgSelected()
    reg = CreateObject("roRegistrySection", "HydraHD")
    idx = m.ccBgRow.buttonSelected
    if idx = 0 then
        reg.Write("ccBgColor", "0x000000")
        reg.Write("ccBgOpacity", "100")
    else if idx = 1 then
        reg.Write("ccBgColor", "0x000000")
        reg.Write("ccBgOpacity", "60")
    else if idx = 2 then
        reg.Write("ccBgOpacity", "0")
    end if
    reg.Flush()
    paintCcPreview()
end sub

sub paintCcPreview()
    reg = CreateObject("roRegistrySection", "HydraHD")
    sz = "medium"
    if reg.Exists("ccTextSize") then sz = reg.Read("ccTextSize")
    color = "0xffffffff"
    if reg.Exists("ccTextColor") then color = reg.Read("ccTextColor") + "ff"
    bgOpacity = 60
    if reg.Exists("ccBgOpacity") then bgOpacity = reg.Read("ccBgOpacity").ToInt()
    bgHex = "000000"
    if reg.Exists("ccBgColor") then bgHex = Mid(reg.Read("ccBgColor"), 3)
    alpha = Cint(bgOpacity * 255 / 100)
    if alpha > 255 then alpha = 255
    aHex = StrI(alpha, 16)
    if Len(aHex) = 1 then aHex = "0" + aHex
    bgFull = "0x" + bgHex + aHex

    if sz = "small" then
        m.ccPreview.font = "font:SmallBoldSystemFont"
    else if sz = "large" then
        m.ccPreview.font = "font:LargeBoldSystemFont"
    else
        m.ccPreview.font = "font:MediumBoldSystemFont"
    end if
    m.ccPreview.color = color
    m.ccPreviewBg.color = bgFull
end sub

' Find which row is currently focused, or -1.
'
' isInFocusChain returns true if this node OR any of its descendants
' has focus. ButtonGroup.setFocus(true) actually focuses the underlying
' Button child, so plain hasFocus() returns false on the ButtonGroup
' itself - which made the previous version of this helper always return
' -1 and silently swallow up/down navigation.
function focusedRowIndex() as Integer
    for i = 0 to m.rowOrder.Count() - 1
        if m.rowOrder[i].isInFocusChain() then return i
    end for
    return -1
end function

' Translate the LayoutGroup vertically so the currently-focused row
' stays inside the visible viewport. Roku's LayoutGroup auto-stacks
' the group children but doesn't scroll on its own; we shift the whole
' group up when the user navigates to a row that would otherwise sit
' below the screen. The viewport is loosely [120, 980] - enough room
' for the page title at the top and a small bottom margin.
sub scrollToFocusedRow()
    if m.layoutGroup = invalid then return
    if m.currentRow = invalid then return
    if m.rowOrder = invalid or m.currentRow >= m.rowOrder.Count() then return
    row = m.rowOrder[m.currentRow]
    if row = invalid then return
    rect = row.sceneBoundingRect()
    if rect = invalid then return

    viewportTop = 120
    viewportBottom = 980
    rowH = rect.height
    if rowH = invalid or rowH < 1 then rowH = 60

    delta = 0
    if rect.y < viewportTop then
        delta = viewportTop - rect.y
    else if rect.y + rowH > viewportBottom then
        delta = -(rect.y + rowH - viewportBottom)
    end if
    if delta = 0 then return

    cur = m.layoutGroup.translation
    if cur = invalid then return
    newY = cur[1] + delta
    if newY > m.layoutGroupBaseY then newY = m.layoutGroupBaseY
    m.layoutGroup.translation = [cur[0], newY]
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false

    ' Modal keyboard - back / cancel routes back to the rows.
    if m.urlEditGroup.visible then
        if key = "back" then
            m.urlEditGroup.visible = false
            m.baseRow.setFocus(true)
            m.currentRow = 0
            return true
        end if
        if key = "down" and m.urlKb.isInFocusChain() then
            m.urlActionsRow.setFocus(true)
            return true
        end if
        if key = "up" and m.urlActionsRow.isInFocusChain() then
            m.urlKb.setFocus(true)
            return true
        end if
        return false
    end if

    rowIdx = focusedRowIndex()
    ' Fall back to the cached row if isInFocusChain failed for some reason
    ' (e.g. focus transiently sitting on the View root after a re-focus).
    if rowIdx < 0 then
        if m.currentRow <> invalid then rowIdx = m.currentRow else rowIdx = 0
    end if
    if key = "down" then
        if rowIdx + 1 < m.rowOrder.Count() then
            m.rowOrder[rowIdx + 1].setFocus(true)
            m.currentRow = rowIdx + 1
            scrollToFocusedRow()
            return true
        end if
        return false
    end if
    if key = "up" then
        if rowIdx > 0 then
            m.rowOrder[rowIdx - 1].setFocus(true)
            m.currentRow = rowIdx - 1
            scrollToFocusedRow()
            return true
        end if
        ' At top row - bubble to MainScene so it can re-focus the nav bar.
        return false
    end if
    return false
end function
