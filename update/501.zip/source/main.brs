' main.brs - Channel entry point.

sub Main(args as Dynamic)
    seedDefaults()

    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.setMessagePort(port)

    scene = screen.CreateScene("MainScene")
    screen.show()

    ' Deep links: a specific title (contentId) OR a voice/OS search term
    ' (mediaType="search", or a q/query arg). MainScene routes a search
    ' term straight into the Search view pre-filled. Voice search itself
    ' is an OS feature that requires the channel's Roku Search feed to be
    ' configured on a published channel; this is the in-channel landing.
    if args <> invalid then
        if args.contentId <> invalid or args.mediaType <> invalid or args.q <> invalid or args.query <> invalid then
            scene.deepLink = args
        end if
    end if

    ' SideMenu's "Exit" button flips this field; we treat it like a
    ' user-initiated close so the channel returns to the home screen
    ' instead of just hiding the UI.
    scene.observeField("exitRequested", port)

    while true
        msg = wait(0, port)
        if type(msg) = "roSGScreenEvent" then
            if msg.isScreenClosed() then return
        else if type(msg) = "roSGNodeEvent" then
            if msg.getField() = "exitRequested" and msg.getData() = true then
                screen.close()
                return
            end if
        end if
    end while
end sub

' Write per-channel defaults the first time the channel runs. Users can
' override anything here later via the Settings screen.
'
' Auto-discovery is currently disabled (it was freezing the channel on
' title selection). The LAN resolver URL is baked in via
' U_DefaultResolverUrl() and used whenever the registry slot is empty.
sub seedDefaults()
    reg = CreateObject("roRegistrySection", "HydraHD")
    base = U_DefaultBaseUrl()
    if reg.Exists("baseUrl") then base = U_NormalizeBaseUrl(reg.Read("baseUrl"))
    reg.Write("baseUrl", base)
    if not reg.Exists("resolverUrl") then
        reg.Write("resolverUrl", "http://192.168.3.180:8787")
    end if
    reg.Flush()
end sub
